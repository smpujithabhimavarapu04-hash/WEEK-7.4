# Java Producer-Consumer Lab — Experiment 4.1

## Aim
Implement the Producer-Consumer problem using a fixed-capacity `LinkedList`, `synchronized`, `wait()`, and `notify()`.

## File
- `ProducerConsumerDemo.java`

## Run on macOS / Linux
Open Terminal in this folder and run:

```bash
javac ProducerConsumerDemo.java
java ProducerConsumerDemo
```

The program runs continuously. Stop it with **Control+C**.

## Expected output (sample)
```text
Producer produced-0
Consumer consumed-0
Producer produced-1
Producer produced-2
Consumer consumed-1
...
```

The exact order and timing can vary because the producer and consumer run concurrently. The buffer capacity is 2. The producer waits while the buffer is full, and the consumer waits while it is empty.
